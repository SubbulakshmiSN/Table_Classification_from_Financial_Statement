# Financial Statement Classification Project Report

## Introduction

This project aims to classify tables extracted from financial statements into categories: Income Statements, Balance Sheets, Cash Flows, Notes, and Others. The classification was achieved using various machine learning models, with a focus on model performance and accuracy.

## Imports


```python
# Import libraries
# file processing
import os
from bs4 import BeautifulSoup

# data processing
import pandas as pd
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import CountVectorizer

# machine learning
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report ,confusion_matrix, f1_score, precision_score, recall_score
from sklearn.svm import SVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from xgboost import XGBClassifier
from sklearn.neural_network import MLPClassifier

# visualization
import matplotlib.pyplot as plt
import seaborn as sns

# ignore warnings
import warnings
warnings.filterwarnings('ignore')

```

## Data Extraction and preprocessing

### Data Extraction

Text was extracted from HTML files using BeautifulSoup. This library is effective for parsing HTML and XML documents and extracting data from them.


```python
def extract_text_from_html(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read()
    soup = BeautifulSoup(content, 'html.parser')
    text = soup.get_text(separator=' ', strip=True)
    return text

def process_specific_directories_to_dataframe(base_dir, folders):
    data = []
    
    # Iterate through each specified folder
    for folder in folders:
        folder_path = os.path.join(base_dir, folder)
        if os.path.isdir(folder_path):
            # Iterate through each HTML file in the folder
            for file_name in os.listdir(folder_path):
                if file_name.endswith('.html'):
                    file_path = os.path.join(folder_path, file_name)
                    extracted_text = extract_text_from_html(file_path)
                    data.append({'text': extracted_text, 'category': folder})
    
    # Create a DataFrame
    df = pd.DataFrame(data)
    return df
```


```python
base_dir = 'C:/Users/Admin/Downloads/data_finclav/data'
folders = ['Balance Sheets', 'Cash Flow', 'Income Statement', 'Notes', 'Others']
df = process_specific_directories_to_dataframe(base_dir, folders)

# Display the DataFrame
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>text</th>
      <th>category</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>(7 in lacs) (7 in lacs) _1_ Standalone Consoli...</td>
      <td>Balance Sheets</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Consolidated Standalone Particulars As at As a...</td>
      <td>Balance Sheets</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Standalone Consolidated Audited Audited Partic...</td>
      <td>Balance Sheets</td>
    </tr>
    <tr>
      <th>3</th>
      <td>GUJARAT NARMADA VALLEY FERTILIZERS &amp; CHEMICALS...</td>
      <td>Balance Sheets</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Standalone Consolidated As at As at As at As a...</td>
      <td>Balance Sheets</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.to_csv('data_extract.csv')
```


```python
df.shape
```




    (2525, 2)




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2525 entries, 0 to 2524
    Data columns (total 2 columns):
     #   Column    Non-Null Count  Dtype 
    ---  ------    --------------  ----- 
     0   text      2525 non-null   object
     1   category  2525 non-null   object
    dtypes: object(2)
    memory usage: 39.6+ KB
    

###  Preprocessing

Preprocessing steps included removing unwanted characters, digits, punctuation, extra spaces, converting text to lowercase, and stemming. These steps ensure that the text data is clean and standardized, making it suitable for machine learning models.



```python
df.isnull().sum()
```




    text        0
    category    0
    dtype: int64




```python
df["text"][0]
```




    '(7 in lacs) (7 in lacs) _1_ Standalone Consolidated Sr. No. Particulars As at 31st March 2018 As at 31st March 2017 As at 31st March 2018 As at 31st March 2017 A Assets 1) Non-Current Assets (a) Property, Plant and Equipment 10,723.96 9,281.23 10,723.96 9,281.23 (b) Capital work in progress 607.46 - 607.46 - (c) Intangible assets 17.44 18.71 17.44 18.71 (d) Financial assets (i) Non-current investments 150.00 150.00 63.42 24.69 (ii) Loans - - - - (iii) Other financial assets 197.66 130.62 197.66 130.62 (e) Other non-current assets - - - - Total Non-Current Assets (A) 11,696.52 9,580.56 11,609.94 9,455.25 2) Current Assets (a) Inventories 8,002.02 13,925.10 8,002.02 13,925.10 (b) Financial assets (i) Trade Receivables 18,541.75 13,671.01 18,541.75 13,671.01 (ii) Cash and cash equivalents 2,883.82 177.11 2,883.82 177.11 (iii) Bank balances other than (ii) above 357.08 1,538.45 357.08 1,538.45 (ivj Loans 3.12 1.79 3.12 1.79 (v) Other Financial assets 220.19 1,035.36 220.19 1,035.36 (c) Other current assets 684.59 2,169.81 684.59 2,169.81 Total Current Assets (B) 30,692.57 32,518.63 30,692.57 32,518.63 - Total Assets (A)+ (B) 42,389.09 42,099.19 42,302.51 41,973.88 B Equity & Liabilities 1) Equity ______ (a) Equity share capital 1,659.06 1,659.06 1,659.06 1,659.06 (b) Other Equity 24,154.09 14,611.93 24,067.51 14,486.61 Total Equity (A) 25,813.15 16,270.99 25,726.57 16,145.67 2) Liabilities Non-Current Liabilities (a) Financial Liabilities (i) Long term borrowings - - - - (ii) Other Non Current Financial Liability 0.30 0.30 0.30 0.30 (bj Long term provisions 449.43 401.26 449.43 401.26 (c) Deferred tax liabilities (Net) 1,061.51 399.63 1,061.51 399.63 Total Non-Current Liabilities (B) 1,511.24 801.19 1,511.24 801.19 Current Liabilities (a) Financial Liabilities (i) Short term borrowings - 13,710.19 - 13,710.19 (ii) Trade payables 12,574.73 9,872.63 12,574.73 9,872.63 (iii) Other Current Financial liabilities 295.21 453.44 295.21 453.44 (b) Other current liabilities 793.04 161.10 793.04 161/19 (c)Short term provisions 40/07 38.26 40.07 38.26 (d) Current tax liabilities (Net) 1,361/65 791.32 1,361.65 791.32 Total Current Liabilities (C) 15,064.70 25,027.03 15,064.70 25,027.03 Total Equity and Liabilities (A)+ (B) +( C) 42,389.09 42,099.19 42,302.51 41,973.88'



### Removing unwanted characters, Digits,Punctuations and extra spaces

- Unwanted characters, digits, and punctuation are removed to retain only the text data.
- Extra spaces are removed, and leading/trailing spaces are trimmed to ensure consistency.


```python
df['clean_text'] = df['text'].apply(lambda x: re.sub(r'[^a-zA-Z\s]', ' ', x))
df['clean_text'] = df['clean_text'].apply(lambda x: re.sub(r'\s+', ' ', x).strip())
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>text</th>
      <th>category</th>
      <th>clean_text</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>(7 in lacs) (7 in lacs) _1_ Standalone Consoli...</td>
      <td>Balance Sheets</td>
      <td>in lacs in lacs Standalone Consolidated Sr No ...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Consolidated Standalone Particulars As at As a...</td>
      <td>Balance Sheets</td>
      <td>Consolidated Standalone Particulars As at As a...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Standalone Consolidated Audited Audited Partic...</td>
      <td>Balance Sheets</td>
      <td>Standalone Consolidated Audited Audited Partic...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>GUJARAT NARMADA VALLEY FERTILIZERS &amp; CHEMICALS...</td>
      <td>Balance Sheets</td>
      <td>GUJARAT NARMADA VALLEY FERTILIZERS CHEMICALS L...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Standalone Consolidated As at As at As at As a...</td>
      <td>Balance Sheets</td>
      <td>Standalone Consolidated As at As at As at As a...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2520</th>
      <td>1. Singhi &amp; Co., 2. Chatterjee &amp; Co., 3. V.K. ...</td>
      <td>Others</td>
      <td>Singhi Co Chatterjee Co V K Dhingra Co A K Sab...</td>
    </tr>
    <tr>
      <th>2521</th>
      <td>Singhi &amp; Co. Chatterjee &amp;Co. V.K. Dhingra &amp; Co...</td>
      <td>Others</td>
      <td>Singhi Co Chatterjee Co V K Dhingra Co A K Sab...</td>
    </tr>
    <tr>
      <th>2522</th>
      <td>r* • • *“•" 1 1 i • • 1 1 1 STEEL AUTHORITY OF...</td>
      <td>Others</td>
      <td>r i STEEL AUTHORITY OF INDIA LIMITED CIN L DL ...</td>
    </tr>
    <tr>
      <th>2523</th>
      <td>Particulars Quarter ended Year ended March 31,...</td>
      <td>Others</td>
      <td>Particulars Quarter ended Year ended March Aud...</td>
    </tr>
    <tr>
      <th>2524</th>
      <td>Particulars Quarter Ended Year Ended March 31,...</td>
      <td>Others</td>
      <td>Particulars Quarter Ended Year Ended March Mar...</td>
    </tr>
  </tbody>
</table>
<p>2525 rows × 3 columns</p>
</div>



### Converting Text to Lowercase

Text is converted to lowercase to maintain uniformity.


```python
# Convert text to lowercase
df['clean_text'] = df['clean_text'].apply(lambda x: x.lower())
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>text</th>
      <th>category</th>
      <th>clean_text</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>(7 in lacs) (7 in lacs) _1_ Standalone Consoli...</td>
      <td>Balance Sheets</td>
      <td>in lacs in lacs standalone consolidated sr no ...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Consolidated Standalone Particulars As at As a...</td>
      <td>Balance Sheets</td>
      <td>consolidated standalone particulars as at as a...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Standalone Consolidated Audited Audited Partic...</td>
      <td>Balance Sheets</td>
      <td>standalone consolidated audited audited partic...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>GUJARAT NARMADA VALLEY FERTILIZERS &amp; CHEMICALS...</td>
      <td>Balance Sheets</td>
      <td>gujarat narmada valley fertilizers chemicals l...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Standalone Consolidated As at As at As at As a...</td>
      <td>Balance Sheets</td>
      <td>standalone consolidated as at as at as at as a...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2520</th>
      <td>1. Singhi &amp; Co., 2. Chatterjee &amp; Co., 3. V.K. ...</td>
      <td>Others</td>
      <td>singhi co chatterjee co v k dhingra co a k sab...</td>
    </tr>
    <tr>
      <th>2521</th>
      <td>Singhi &amp; Co. Chatterjee &amp;Co. V.K. Dhingra &amp; Co...</td>
      <td>Others</td>
      <td>singhi co chatterjee co v k dhingra co a k sab...</td>
    </tr>
    <tr>
      <th>2522</th>
      <td>r* • • *“•" 1 1 i • • 1 1 1 STEEL AUTHORITY OF...</td>
      <td>Others</td>
      <td>r i steel authority of india limited cin l dl ...</td>
    </tr>
    <tr>
      <th>2523</th>
      <td>Particulars Quarter ended Year ended March 31,...</td>
      <td>Others</td>
      <td>particulars quarter ended year ended march aud...</td>
    </tr>
    <tr>
      <th>2524</th>
      <td>Particulars Quarter Ended Year Ended March 31,...</td>
      <td>Others</td>
      <td>particulars quarter ended year ended march mar...</td>
    </tr>
  </tbody>
</table>
<p>2525 rows × 3 columns</p>
</div>




```python
df["clean_text"][0]
```




    'in lacs in lacs standalone consolidated sr no particulars as at st march as at st march as at st march as at st march a assets non current assets a property plant and equipment b capital work in progress c intangible assets d financial assets i non current investments ii loans iii other financial assets e other non current assets total non current assets a current assets a inventories b financial assets i trade receivables ii cash and cash equivalents iii bank balances other than ii above ivj loans v other financial assets c other current assets total current assets b total assets a b b equity liabilities equity a equity share capital b other equity total equity a liabilities non current liabilities a financial liabilities i long term borrowings ii other non current financial liability bj long term provisions c deferred tax liabilities net total non current liabilities b current liabilities a financial liabilities i short term borrowings ii trade payables iii other current financial liabilities b other current liabilities c short term provisions d current tax liabilities net total current liabilities c total equity and liabilities a b c'



### Stemming

Words are reduced to their root form using stemming, which helps in standardizing the text data.


```python
## Stemming
ps = PorterStemmer()
```


```python
def stem(text):
  y = []
  for i in text.split():
    y.append(ps.stem(i))
  return " ".join(y)
```


```python
df['clean_text'] = df['clean_text'].apply(stem)
```


```python
df.clean_text[0]
```




    'in lac in lac standalon consolid sr no particular as at st march as at st march as at st march as at st march a asset non current asset a properti plant and equip b capit work in progress c intang asset d financi asset i non current invest ii loan iii other financi asset e other non current asset total non current asset a current asset a inventori b financi asset i trade receiv ii cash and cash equival iii bank balanc other than ii abov ivj loan v other financi asset c other current asset total current asset b total asset a b b equiti liabil equiti a equiti share capit b other equiti total equiti a liabil non current liabil a financi liabil i long term borrow ii other non current financi liabil bj long term provis c defer tax liabil net total non current liabil b current liabil a financi liabil i short term borrow ii trade payabl iii other current financi liabil b other current liabil c short term provis d current tax liabil net total current liabil c total equiti and liabil a b c'



### Encoding the target variable

The target variable (categories) is encoded into numerical values using LabelEncoder.


```python
## encoding the target variable
encoder = LabelEncoder()
df['category'] = encoder.fit_transform(df['category'])
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>text</th>
      <th>category</th>
      <th>clean_text</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>(7 in lacs) (7 in lacs) _1_ Standalone Consoli...</td>
      <td>0</td>
      <td>in lac in lac standalon consolid sr no particu...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Consolidated Standalone Particulars As at As a...</td>
      <td>0</td>
      <td>consolid standalon particular as at as at mar ...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Standalone Consolidated Audited Audited Partic...</td>
      <td>0</td>
      <td>standalon consolid audit audit particular as a...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>GUJARAT NARMADA VALLEY FERTILIZERS &amp; CHEMICALS...</td>
      <td>0</td>
      <td>gujarat narmada valley fertil chemic limit sta...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Standalone Consolidated As at As at As at As a...</td>
      <td>0</td>
      <td>standalon consolid as at as at as at as at par...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2520</th>
      <td>1. Singhi &amp; Co., 2. Chatterjee &amp; Co., 3. V.K. ...</td>
      <td>4</td>
      <td>singhi co chatterje co v k dhingra co a k saba...</td>
    </tr>
    <tr>
      <th>2521</th>
      <td>Singhi &amp; Co. Chatterjee &amp;Co. V.K. Dhingra &amp; Co...</td>
      <td>4</td>
      <td>singhi co chatterje co v k dhingra co a k saba...</td>
    </tr>
    <tr>
      <th>2522</th>
      <td>r* • • *“•" 1 1 i • • 1 1 1 STEEL AUTHORITY OF...</td>
      <td>4</td>
      <td>r i steel author of india limit cin l dl go re...</td>
    </tr>
    <tr>
      <th>2523</th>
      <td>Particulars Quarter ended Year ended March 31,...</td>
      <td>4</td>
      <td>particular quarter end year end march audit re...</td>
    </tr>
    <tr>
      <th>2524</th>
      <td>Particulars Quarter Ended Year Ended March 31,...</td>
      <td>4</td>
      <td>particular quarter end year end march march de...</td>
    </tr>
  </tbody>
</table>
<p>2525 rows × 3 columns</p>
</div>



## Model Training and evaluation

### Data splitting and vectorization

The dataset is split into training and testing sets. The text data is then transformed into numerical vectors using CountVectorizer.


```python
x= df['clean_text']
y = df['category']
x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.2, random_state=0)
```


```python

cv = CountVectorizer(max_features=5000,stop_words='english')
```


```python
x_train_cv = cv.fit_transform(x_train)
x_test_cv = cv.transform(x_test)

```

### Training and Evaluation Function

A function is created to train and evaluate the models, calculating accuracy, precision, recall, and F1 score.


```python
def train_and_evaluate_model(model):
    model.fit(x_train_cv, y_train)
    y_pred = model.predict(x_test_cv)
    accuracy = round(accuracy_score(y_test, y_pred),2)
    precision = round(precision_score(y_test, y_pred, average='weighted'),2)
    recall = round(recall_score(y_test, y_pred, average='weighted'),2)
    f1 = round(f1_score(y_test, y_pred, average='weighted'),2)
    return accuracy, precision, recall, f1
```

### Models Used

- __Support Vector Machine (SVM)-__
SVM is effective in high-dimensional spaces and is often used for text classification.

- __Multinomial Naive Bayes-__
Naive Bayes classifiers are particularly suited for text classification tasks due to their simplicity and efficiency.

- __Random Forest-__
An ensemble method that builds multiple decision trees and merges them to get a more accurate and stable prediction.

- __Logistic Regression-__
A statistical model that in its basic form uses a logistic function to model a binary dependent variable.

- __XGBoost-__
An optimized gradient-boosting algorithm that is highly efficient and accurate.

- __Multilayer Perceptron (Neural Network)-__
A type of neural network that consists of multiple layers of nodes, each fully connected to the next layer. It is capable of capturing complex patterns in data.



```python
# Initialize models
models = {
    "Support Vector Machine (SVM)": SVC(kernel='linear', random_state=42),
    "Multinomial Naive Bayes": MultinomialNB(),
    "Random Forest": RandomForestClassifier(n_estimators=100, random_state=42),
    "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
    "XGBoost": XGBClassifier(verbosity=0, random_state=42),
    "Multilayer Perceptron (Neural Network)": MLPClassifier(hidden_layer_sizes=(100,), max_iter=1000, random_state=42)
}
```

### Model Comparison

The models were trained and evaluated, and their performance metrics were collected.


```python
# List to store metrics
metrics_list = []

# Train and evaluate models
for name, model in models.items():
    accuracy, precision, recall, f1 = train_and_evaluate_model(model)
    print(f"{name} Accuracy:", accuracy)
    print(f"{name} Classification Report:\n", classification_report(y_test, model.predict(x_test_cv), target_names=encoder.classes_))
    print("confusion matrix:\n", confusion_matrix(y_test, model.predict(x_test_cv)))
    print("=" * 60)
    metrics_list.append({
        'Model': name,
        'Accuracy': accuracy,
        'Precision': precision,
        'Recall': recall,
        'F1 Score': f1
    })
    
# Convert metrics list to DataFrame
metrics_df = pd.DataFrame(metrics_list)
metrics_df.sort_values(by='Accuracy',ascending=False,inplace=True)
```

    Support Vector Machine (SVM) Accuracy: 0.94
    Support Vector Machine (SVM) Classification Report:
                       precision    recall  f1-score   support
    
      Balance Sheets       0.94      1.00      0.97        48
           Cash Flow       1.00      1.00      1.00         6
    Income Statement       0.91      0.93      0.92        57
               Notes       0.94      0.93      0.93       147
              Others       0.94      0.94      0.94       247
    
            accuracy                           0.94       505
           macro avg       0.95      0.96      0.95       505
        weighted avg       0.94      0.94      0.94       505
    
    confusion matrix:
     [[ 48   0   0   0   0]
     [  0   6   0   0   0]
     [  0   0  53   0   4]
     [  0   0   0 136  11]
     [  3   0   5   8 231]]
    ============================================================
    Multinomial Naive Bayes Accuracy: 0.84
    Multinomial Naive Bayes Classification Report:
                       precision    recall  f1-score   support
    
      Balance Sheets       0.80      1.00      0.89        48
           Cash Flow       0.75      1.00      0.86         6
    Income Statement       0.62      0.98      0.76        57
               Notes       0.84      0.90      0.87       147
              Others       0.97      0.74      0.84       247
    
            accuracy                           0.84       505
           macro avg       0.80      0.93      0.84       505
        weighted avg       0.87      0.84      0.85       505
    
    confusion matrix:
     [[ 48   0   0   0   0]
     [  0   6   0   0   0]
     [  0   0  56   0   1]
     [  3   1   7 132   4]
     [  9   1  27  26 184]]
    ============================================================
    Random Forest Accuracy: 0.97
    Random Forest Classification Report:
                       precision    recall  f1-score   support
    
      Balance Sheets       0.96      0.98      0.97        48
           Cash Flow       1.00      0.83      0.91         6
    Income Statement       1.00      0.95      0.97        57
               Notes       0.95      0.97      0.96       147
              Others       0.97      0.97      0.97       247
    
            accuracy                           0.97       505
           macro avg       0.98      0.94      0.96       505
        weighted avg       0.97      0.97      0.97       505
    
    confusion matrix:
     [[ 47   0   0   1   0]
     [  0   5   0   1   0]
     [  0   0  54   0   3]
     [  0   0   0 142   5]
     [  2   0   0   5 240]]
    ============================================================
    Logistic Regression Accuracy: 0.95
    Logistic Regression Classification Report:
                       precision    recall  f1-score   support
    
      Balance Sheets       0.94      1.00      0.97        48
           Cash Flow       1.00      1.00      1.00         6
    Income Statement       0.95      0.93      0.94        57
               Notes       0.97      0.93      0.95       147
              Others       0.95      0.96      0.96       247
    
            accuracy                           0.95       505
           macro avg       0.96      0.97      0.96       505
        weighted avg       0.95      0.95      0.95       505
    
    confusion matrix:
     [[ 48   0   0   0   0]
     [  0   6   0   0   0]
     [  0   0  53   0   4]
     [  0   0   1 137   9]
     [  3   0   2   4 238]]
    ============================================================
    XGBoost Accuracy: 0.96
    XGBoost Classification Report:
                       precision    recall  f1-score   support
    
      Balance Sheets       0.96      1.00      0.98        48
           Cash Flow       1.00      1.00      1.00         6
    Income Statement       0.98      0.95      0.96        57
               Notes       0.97      0.95      0.96       147
              Others       0.96      0.97      0.96       247
    
            accuracy                           0.96       505
           macro avg       0.97      0.97      0.97       505
        weighted avg       0.96      0.96      0.96       505
    
    confusion matrix:
     [[ 48   0   0   0   0]
     [  0   6   0   0   0]
     [  0   0  54   0   3]
     [  0   0   0 139   8]
     [  2   0   1   4 240]]
    ============================================================
    Multilayer Perceptron (Neural Network) Accuracy: 0.96
    Multilayer Perceptron (Neural Network) Classification Report:
                       precision    recall  f1-score   support
    
      Balance Sheets       0.96      1.00      0.98        48
           Cash Flow       1.00      1.00      1.00         6
    Income Statement       0.96      0.89      0.93        57
               Notes       0.95      0.97      0.96       147
              Others       0.96      0.96      0.96       247
    
            accuracy                           0.96       505
           macro avg       0.97      0.96      0.96       505
        weighted avg       0.96      0.96      0.96       505
    
    confusion matrix:
     [[ 48   0   0   0   0]
     [  0   6   0   0   0]
     [  0   0  51   0   6]
     [  0   0   0 142   5]
     [  2   0   2   7 236]]
    ============================================================
    


```python
metrics_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model</th>
      <th>Accuracy</th>
      <th>Precision</th>
      <th>Recall</th>
      <th>F1 Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>Random Forest</td>
      <td>0.97</td>
      <td>0.97</td>
      <td>0.97</td>
      <td>0.97</td>
    </tr>
    <tr>
      <th>4</th>
      <td>XGBoost</td>
      <td>0.96</td>
      <td>0.96</td>
      <td>0.96</td>
      <td>0.96</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Multilayer Perceptron (Neural Network)</td>
      <td>0.96</td>
      <td>0.96</td>
      <td>0.96</td>
      <td>0.96</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Logistic Regression</td>
      <td>0.95</td>
      <td>0.95</td>
      <td>0.95</td>
      <td>0.95</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Support Vector Machine (SVM)</td>
      <td>0.94</td>
      <td>0.94</td>
      <td>0.94</td>
      <td>0.94</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Multinomial Naive Bayes</td>
      <td>0.84</td>
      <td>0.87</td>
      <td>0.84</td>
      <td>0.85</td>
    </tr>
  </tbody>
</table>
</div>



### Plotting the Results


```python
# Plot the accuracies
plt.figure(figsize=(10, 6))
sns.barplot(x='Accuracy', y='Model', data=metrics_df)
plt.title('Model Accuracy Comparison')
plt.xlabel('Accuracy')
plt.ylabel('Model')
plt.show()
```


    
![png](output_37_0.png)
    


## Conclusion

Based on the evaluation metrics, the __Random Forest model__ achieved the highest accuracy at 97%, followed closely by __XGBoost__ and __Multilayer Perceptron__, each with an accuracy of 96%.


## Recommendations

Given the high accuracy and robust performance across multiple metrics, the __Random Forest model__ is recommended for deployment in the classification of financial statement tables. The model's ensemble nature makes it particularly suitable for handling diverse and complex datasets.


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
